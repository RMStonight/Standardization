#!/bin/bash

# 设置root密码
printf "Setting up root password...\n"
printf "ruinap\n" | sudo -S passwd root <<< "ruinap"$'\n'"ruinap"$'\n'
#########################################################

# 检索.profile文件的末行
printf "Processing profile...\n"
last_line=$(tail -n 1 /root/.profile)

# 如果末行为“mesg n || true”，则替换为“# mesg n || true”并新增一行“tty -s && mesg n || true”
if [ "$last_line" = "mesg n || true" ]; then
    sed -i '$s/mesg n \|\| true/# mesg n \|\| true\ntty -s \&\& mesg n \|\| true/' /root/.profile
    printf "Change last line...\n"
fi
#########################################################

# 检索/etc/pam.d/gdm-autologin文件的第三行
printf "Processing gdm-autologin...\n"
third_line=$(sed -n '3p' /etc/pam.d/gdm-autologin)

# 如果第三行为“auth required pam_succeed_if.so user != root quiet_success”，则替换为“#auth required pam_succeed_if.so user != root quiet_success”
if [ "$third_line" = "auth	required	pam_succeed_if.so user != root quiet_success" ]; then
  sed -i '3s/^/#/' /etc/pam.d/gdm-autologin
  printf "Change gdm-autologin third line...\n"
fi
#########################################################

# 检索/etc/pam.d/gdm-password文件的第三行
printf "Processing gdm-password...\n"
third_line=$(sed -n '3p' /etc/pam.d/gdm-password)

# 如果第三行为“auth required pam_succeed_if.so user != root quiet_success”，则替换为“#auth required pam_succeed_if.so user != root quiet_success”
if [ "$third_line" = "auth	required	pam_succeed_if.so user != root quiet_success" ]; then
  sed -i '3s/^/#/' /etc/pam.d/gdm-password
  printf "Change gdm-password third line...\n"
fi
#########################################################

# 检索/usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf文件的末行
printf "Processing 50-ubuntu.conf...\n"
last_line=$(tail -n 1 /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf)

# 如果末行为“user-session=ubuntu”，则在后面添加两行内容
if [ "$last_line" = "user-session=ubuntu" ]; then
  sudo sed -i '$a\greeter-show-manual-login=true\nall-guest=false' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf
  printf "Add two lines...\n"
fi
#########################################################

# 检索/etc/gdm3/custom.conf文件中的“AutomaticLogin=ruinap”
printf "Processing custom.conf...\n"
auto_login=$(grep -E "AutomaticLogin=ruinap" /etc/gdm3/custom.conf)

# 如果存在，则将其修改为“AutomaticLogin=root”
if [ -n "$auto_login" ]; then
  sudo sed -i 's/AutomaticLogin=ruinap/AutomaticLogin=root/g' /etc/gdm3/custom.conf
  printf "Change ruinap to root...\n"
fi



