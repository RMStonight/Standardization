#!/bin/bash

printf "Downing openssh-server...\n"
apt update
apt install -y openssh-server
########################################################################

# 检索/etc/ssh/sshd_config文件中的“#PermitRootLogin prohibit-password”
printf "Processing sshd_config...\n"
auto_login=$(grep -E "#PermitRootLogin prohibit-password" /etc/ssh/sshd_config)

# 如果存在，则将其修改为“AutomaticLogin=root”
if [ -n "$auto_login" ]; then
  sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/g' /etc/ssh/sshd_config
  printf "Change PermitRootLogin to yes...\n"
fi
########################################################################

# 检索/etc/ssh/sshd_config文件中的“#PasswordAuthentication yes”
printf "Processing sshd_config...\n"
auto_login=$(grep -E "#PasswordAuthentication yes" /etc/ssh/sshd_config)

# 如果存在，则将其修改为“AutomaticLogin=root”
if [ -n "$auto_login" ]; then
  sed -i 's/#PasswordAuthentication yes/PasswordAuthentication yes/g' /etc/ssh/sshd_config
  printf "Change PasswordAuthentication to yes...\n"
fi
############################################

printf "Processing ssh-keygen...\n"
if [ ! -f /root/.ssh/id_rsa.pub ]; then
    printf "Generating ssh-keygen...\n"
    ssh-keygen -t rsa -N "" <<< $'\n\n\n'
    printf "Copy id_rsa.pub >> authorized_keys...\n"
    cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
fi

apt install net-tools
apt install vim

