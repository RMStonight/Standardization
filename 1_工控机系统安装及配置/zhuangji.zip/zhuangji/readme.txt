----------------------------------------------------------------
step1:
设置工控机以root模式自启
sudo bash step1_root.sh
重启
sudo reboot
----------------------------------------------------------------
step2:
设置工控机允许以root用户登录ssh
bash step2_root_ssh.sh
重启
sudo reboot
----------------------------------------------------------------
step3:
设置网卡
先查询具体的网卡名称和数量
gedit /etc/netplan/01-netcfg.yaml

network:
  version: 2
  renderer: networkd
  ethernets:
    eno1:
      dhcp4: no
      addresses: [192.168.0.100/24]
    enp2s0:
      dhcp4: no
      addresses: [192.168.2.100/24]
    enp3s0:
      dhcp4: no
      addresses: [192.168.3.100/24]
    enp5s0:
      dhcp4: no
      addresses: [192.168.1.100/24]

netplan try
桌的马爹，没有报错，再enter
netplan apply
----------------------------------------------------------------
step4:
配置docker环境
apt update
apt install -y ca-certificates curl gnupg lsb-release
curl -fsSL http://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg | sudo apt-key add -
add-apt-repository "deb [arch=amd64] http://mirrors.aliyun.com/docker-ce/linux/ubuntu $(lsb_release -cs) stable"

apt install -y docker-ce docker-ce-cli containerd.io
systemctl status docker
apt install -y docker-compose
----------------------------------------------------------------
step5:
配置虚拟内存
检查当前虚拟内存大小：
free -m
cd /
mkdir swap
cd swap
dd if=/dev/zero of=swapfile bs=1024 count=12582912
mkswap swapfile
chmod 600 swapfile
swapoff swapfile
swapon swapfile

gedit /etc/fstab    最后一行添加
 /swap/swapfile swap swap defaults 0 0

检查虚拟内存大小：free -m
reboot
----------------------------------------------------------------
step6:
安装第三方工具
apt install -y tmux
apt install -y minicom
apt install -y gnome-shell-extension-manager
----------------------------------------------------------------
step7:
添加RUINAP-LOGO
apt install -y figlet
figlet -f standard RUINAP
gedit /etc/ssh/sshd_config

添加一行
# no default banner path
Banner /etc/ssh/my_banner

figlet -f standard RUINAP >> /etc/ssh/my_banner
reboot
----------------------------------------------------------------
step8:
音频设置
Startup Applications中添加开机自启
Name: start pulseaudio
Command: /usr/bin/pulseaudio

修改配置文件
gedit /etc/modprobe.d/alsa-base.conf
# 打开文件后文件末尾加入这行 options snd-hda-intel dmic_detect=0
gedit /etc/modprobe.d/blacklist.conf 
# 打开文件后文件末尾加入这行 blacklist snd_soc_skl

reboot
----------------------------------------------------------------
step9:
安装docker镜像
docker load -i XXX.tar

