#!/bin/bash

# 检查是否以 root 权限运行
if [ "$EUID" -ne 0 ]; then
  echo "请以 root 权限运行此脚本 (使用 sudo)"
  exit 1
fi

# 1. 安装 figlet
echo "正在更新软件包列表并安装 figlet..."
apt update
apt install -y figlet

# 2. 创建并编辑 ssh_welcome.sh
echo "正在创建 /etc/profile.d/ssh_welcome.sh..."
cat > /etc/profile.d/ssh_welcome.sh << 'EOF'
#!/bin/bash

# 仅对 SSH 登录有效（可选）
if [ -n "$SSH_CONNECTION" ] || [ -n "$SSH_CLIENT" ] || [ -n "$SSH_TTY" ]; then
    # 公司名称
    echo "======================================"
    figlet -f standard RUINAP
    echo "======================================"

    # 系统时间
    echo "Sys. Time: $(date '+%Y-%m-%d %H:%M:%S')"

    # CPU 使用率（取1秒内平均使用率，排除 idle）
    cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print 100 - $8 "%"}')
    echo "CPU Usage: $cpu_usage"

    # 内存使用率
    mem_info=$(free | awk 'NR==2{printf "%.1f%%", $3*100/$2 }')
    echo "Mem Usage: $mem_info"

    # 硬盘剩余空间（根分区）
    disk_avail=$(df -h / | awk 'NR==2 {print $4}')
    disk_usage=$(df -h / | awk 'NR==2 {print $5}')
    echo "DiskUsage: $disk_usage (Free: $disk_avail)"

    echo "======================================"
fi
EOF

# 3. 设置 ssh_welcome.sh 可执行权限
echo "正在设置 /etc/profile.d/ssh_welcome.sh 可执行权限..."
chmod +x /etc/profile.d/ssh_welcome.sh

# 4. 测试 figlet 命令
echo "测试 figlet 输出..."
figlet -f standard RUINAP

# 5. 编辑 /etc/ssh/sshd_config
echo "正在编辑 /etc/ssh/sshd_config..."
if ! grep -q "Banner /etc/ssh/my_banner" /etc/ssh/sshd_config; then
  echo "# no default banner path" >> /etc/ssh/sshd_config
  echo "Banner /etc/ssh/my_banner" >> /etc/ssh/sshd_config
else
  echo "Banner 配置已存在，跳过..."
fi

# 6. 创建或追加 my_banner 文件
echo "正在创建/追加 /etc/ssh/my_banner..."
figlet -f standard RUINAP >> /etc/ssh/my_banner

# 7. 重启 SSH 服务以应用更改
echo "正在重启 SSH 服务..."
systemctl restart sshd

echo "脚本执行完成！"